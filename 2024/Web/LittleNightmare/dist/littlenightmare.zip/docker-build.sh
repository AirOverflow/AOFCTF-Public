#!/bin/bash
docker build -t littlenightmare_web .